A Pen created at CodePen.io. You can find this one at https://codepen.io/DawsonMediaD/pen/Gzwbl.

 Part of a 2-part exploration of puff animations with number transitions, using either jQuery UI's puff transition or CSS3 transition/opacity.